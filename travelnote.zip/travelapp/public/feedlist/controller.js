/* feedlist */
angular.module('travel')
    .controller('feedlist',['$scope', 'fb', function($scope, FB){
        //loginWidthFacebook()
    }])