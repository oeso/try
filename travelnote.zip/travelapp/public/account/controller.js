/* Account */
angular.module('travel')
    .controller('account', function($scope){
        //loginWidthFacebook()
    })